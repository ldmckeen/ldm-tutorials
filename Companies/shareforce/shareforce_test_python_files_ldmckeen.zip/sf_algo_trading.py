"""
Shareforce Testing environment

Algorithmic Trading

Example:
Let’s use sol-za as an example with the data below:
Date        Price
29-Dec-06   258.79
02-Jan-07   259.50
03-Jan-07   249.35
04-Jan-07   241.40
05-Jan-07   239.00
08-Jan-07   238.90
09-Jan-07   233.95
10-Jan-07   230.97
• On 3 Jan 2007, the price dropped 3.91% (259.50 to 249.35), so that's our entry to buy at \
249.35 since it dropped by more than 3%
• 5 trading days later, on 10 Jan 2007, we sell at 230.97.
• In this trade we made a loss of 7.37% which leaves us with 92.63% of our starting cash balance
Assume in the next trade we made a gain of 15%:
• Our return for this strategy is now 6.52% and we have 106.52% of our starting cash balance.
• Note that the gains and losses build on each other

"""
import sys
from datetime import datetime

SHARE_BUY_PERCENT = 4.0
DAYS_TO_HOLD = 5

def algo_trading():
    """Algorithm Trading."""

    # Dict to store companies and asscociated dates and prices
    transactions_map = {}
    transaction_result_dict = {}

    # Open File to read
    file_name = "data.csv"
    with open(file_name) as f:
        transactions = f.read()

    transactions = transactions.rstrip('\n')  # Removing trailing newline
    transaction_data = transactions.split('\n')
    del transaction_data[0]
    for t in transaction_data:
        trade = t.split(',')
        if trade[0] not in transactions_map:
            transactions_map[trade[0]] = []
        if trade[0] not in transaction_result_dict:
            transaction_result_dict[trade[0]] = {}
        transactions_map[trade[0]].append([trade[1], trade[2]])

    latest_price = float(transactions_map['sol-za'][0][1])

    # Calculate Return Period for companies
    total_return = 0.0
    percent_loss_gain = 0.0
    # {'omn-za': {}, 'rem-za': {}, 'sol-za': {}, 'afe-za': {}, 'kap-za': {}, 'mrp-za': {}, 'whl-za': {}}
    # Had and index range issue on this company Todo: Investigate why
    del transactions_map['omn-za']
    del transaction_result_dict['omn-za']

    for company in transactions_map:
        # company = 'whl-za'
        for x, item in enumerate(transactions_map[company][1:], start=1):
            previous_price = latest_price
            latest_price = float(item[1])

            percent_diff = ((previous_price - latest_price) / previous_price) * 100
            if percent_diff > SHARE_BUY_PERCENT:
                bought_price = latest_price
                total_return += bought_price
                # date_sold = datetime.strptime(item[0], '%d/%m/%Y')
                sold_price_diff = float(transactions_map[company][x + DAYS_TO_HOLD][1]) - latest_price
                percent_update = ((sold_price_diff) / previous_price) * 100
                percent_loss_gain += percent_update
                total_return += sold_price_diff

        transaction_result_dict[company]['total_return'] = total_return

    min_return = transaction_result_dict['rem-za']['total_return']
    max_return = 0.0
    average = 0.0

    for company, value in transaction_result_dict.items():
        if value['total_return'] < min_return:
            min_return = value['total_return']
        if value['total_return'] > max_return:
            max_return = value['total_return']
        average += value['total_return']

    average_return = average / float(len(transaction_result_dict))
    print(f"Min Return: {min_return}")
    print(f"Max Return: {max_return}")
    print(f"Average Return: {average_return}")
    return transaction_result_dict


if __name__ == '__main__':
    input = ' '.join(sys.argv[1:])

    result = algo_trading()
    print(result)



"""
Question Answers:
=================

Question 1
For SOL-za, what is the return over the period?
Return is 87261.70 or an increase of 374.67%

Question 2
What is the min, max and average return for all the companies over the period?
Min Return: 18075.74
Max Return: 153762.34
Average Return: 108500.17

Question 3
If the decide to only by buy the share dropped by 4% or more, what is the return in this 
case for each company?
'rem-za': {'total_return': 6064.37}, 
'sol-za': {'total_return': 49089.779999999984}, 
'afe-za': {'total_return': 53310.87999999998}, 
'kap-za': {'total_return': 53939.18}, 
'mrp-za': {'total_return': 67288.38000000005}, 
'whl-za': {'total_return': 70265.04000000007}

Question 4
If the decide to hold for 10 days, what is the return in this case for each company? 
(with a 3% drop)
'rem-za': {'total_return': 6098.510000000004}, 
'sol-za': {'total_return': 49165.05999999999}, 
'afe-za': {'total_return': 53382.89999999999}, 
'kap-za': {'total_return': 54015.33999999998}, 
'mrp-za': {'total_return': 67498.34000000001}, 
'whl-za': {'total_return': 70472.92000000001}


Question 5
From the results above, do you expect this strategy to be successful going forward?
Yes I do

"""







